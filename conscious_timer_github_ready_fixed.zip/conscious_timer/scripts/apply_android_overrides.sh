#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

if [ ! -d android/app/src/main ]; then
  echo "android project is missing. Run: flutter create . --platforms=android --org com.zayed --project-name conscious_timer"
  exit 1
fi

rm -rf android/app/src/main/kotlin/com/zayed/conscious_timer
mkdir -p android/app/src/main/kotlin/com/zayed/conscious_timer
cp -R native_overrides/android/app/src/main/kotlin/com/zayed/conscious_timer/. android/app/src/main/kotlin/com/zayed/conscious_timer/
cp native_overrides/android/app/src/main/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
cp native_overrides/android/app/src/main/res/values/styles.xml android/app/src/main/res/values/styles.xml

echo "Android native alarm overrides applied."
