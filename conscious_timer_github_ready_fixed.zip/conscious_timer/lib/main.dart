import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart' as intl;

import 'models.dart';
import 'native_alarm.dart';
import 'storage.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ConsciousTimerApp());
}

class ConsciousTimerApp extends StatefulWidget {
  const ConsciousTimerApp({super.key});

  @override
  State<ConsciousTimerApp> createState() => _ConsciousTimerAppState();
}

class _ConsciousTimerAppState extends State<ConsciousTimerApp>
    with WidgetsBindingObserver {
  final AppStorage _storage = AppStorage();

  bool _loading = true;
  int _tab = 0;
  ActiveSession? _active;
  List<SessionRecord> _records = <SessionRecord>[];
  List<String> _actions = <String>[];
  List<String> _reflections = <String>[];
  SessionKind? _nextKind;
  int _defaultSnooze = 5;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _consumeNativeAction();
    }
  }

  Future<void> _load() async {
    final values = await Future.wait<Object?>([
      _storage.loadActive(),
      _storage.loadRecords(),
      _storage.loadActions(),
      _storage.loadReflections(),
      _storage.loadNextKind(),
      _storage.loadDefaultSnooze(),
    ]);
    _active = values[0] as ActiveSession?;
    _records = values[1] as List<SessionRecord>;
    _actions = values[2] as List<String>;
    _reflections = values[3] as List<String>;
    _nextKind = values[4] as SessionKind?;
    _defaultSnooze = values[5] as int;
    await _consumeNativeAction(refresh: false);
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _consumeNativeAction({bool refresh = true}) async {
    final action = await NativeAlarm.consumePendingAction();
    if (action == null || action['action'] != 'finish') return;
    final active = _active;
    if (active == null || action['sessionId'] != active.id) return;
    final endedAt = (action['finishedAtMillis'] as num?)?.toInt() ??
        DateTime.now().millisecondsSinceEpoch;
    final snoozes = (action['snoozeCount'] as num?)?.toInt() ?? 0;
    await _finalizeActive(
      endedAtMillis: endedAt,
      snoozeCount: snoozes,
      cancelNative: false,
      refresh: refresh,
    );
  }

  Future<bool> _startSession({
    required SessionKind kind,
    required String name,
    required int minutes,
    required int snoozeMinutes,
  }) async {
    if (_active != null) return false;
    final now = DateTime.now().millisecondsSinceEpoch;
    final session = ActiveSession(
      id: '$now-${kind.key}',
      kind: kind,
      name: name,
      plannedMinutes: minutes,
      snoozeMinutes: snoozeMinutes,
      startedAtMillis: now,
    );
    final scheduled = await NativeAlarm.schedule(
      triggerAtMillis: session.plannedEndMillis,
      sessionId: session.id,
      title: kind == SessionKind.action
          ? 'انتهى وقت $name'
          : 'انتهت جلسة $name',
      body: kind == SessionKind.action
          ? 'حان وقت جلسة الوعي.'
          : 'حان وقت بدء الفعل التالي.',
      snoozeMinutes: snoozeMinutes,
    );
    if (!scheduled) return false;
    _active = session;
    _nextKind = null;
    await Future.wait([
      _storage.saveActive(session),
      _storage.saveNextKind(null),
    ]);
    if (mounted) setState(() {});
    return true;
  }

  Future<void> _finishFromApp() async {
    final active = _active;
    if (active == null) return;
    final snoozes = await NativeAlarm.getSnoozeCount();
    await _finalizeActive(
      endedAtMillis: DateTime.now().millisecondsSinceEpoch,
      snoozeCount: snoozes,
      cancelNative: true,
    );
  }

  Future<void> _finalizeActive({
    required int endedAtMillis,
    required int snoozeCount,
    required bool cancelNative,
    bool refresh = true,
  }) async {
    final active = _active;
    if (active == null) return;
    if (cancelNative) await NativeAlarm.cancel();
    final record = SessionRecord(
      id: active.id,
      kind: active.kind,
      name: active.name,
      plannedMinutes: active.plannedMinutes,
      snoozeMinutes: active.snoozeMinutes,
      startedAtMillis: active.startedAtMillis,
      endedAtMillis: endedAtMillis,
      snoozeCount: snoozeCount,
    );
    _records = [record, ..._records];
    _active = null;
    _nextKind = active.kind == SessionKind.action
        ? SessionKind.reflection
        : SessionKind.action;
    await Future.wait([
      _storage.saveActive(null),
      _storage.saveRecords(_records),
      _storage.saveNextKind(_nextKind),
    ]);
    if (refresh && mounted) setState(() {});
  }

  Future<void> _extendActive(int minutes) async {
    final active = _active;
    if (active == null) return;
    final updated = ActiveSession(
      id: active.id,
      kind: active.kind,
      name: active.name,
      plannedMinutes: active.plannedMinutes + minutes,
      snoozeMinutes: active.snoozeMinutes,
      startedAtMillis: active.startedAtMillis,
    );
    final ok = await NativeAlarm.schedule(
      triggerAtMillis: updated.plannedEndMillis,
      sessionId: updated.id,
      title: updated.kind == SessionKind.action
          ? 'انتهى وقت ${updated.name}'
          : 'انتهت جلسة ${updated.name}',
      body: updated.kind == SessionKind.action
          ? 'حان وقت جلسة الوعي.'
          : 'حان وقت بدء الفعل التالي.',
      snoozeMinutes: updated.snoozeMinutes,
    );
    if (!ok) return;
    _active = updated;
    await _storage.saveActive(updated);
    if (mounted) setState(() {});
  }

  Future<void> _saveNames(SessionKind kind, List<String> names) async {
    if (kind == SessionKind.action) {
      _actions = names;
      await _storage.saveActions(names);
    } else {
      _reflections = names;
      await _storage.saveReflections(names);
    }
    if (mounted) setState(() {});
  }

  Future<void> _setDefaultSnooze(int value) async {
    _defaultSnooze = value;
    await _storage.saveDefaultSnooze(value);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'فعل وجلسة',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF40513B),
        scaffoldBackgroundColor: const Color(0xFFF7F7F3),
      ),
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: _loading
            ? const Scaffold(body: Center(child: CircularProgressIndicator()))
            : Scaffold(
                body: SafeArea(
                  child: IndexedStack(
                    index: _tab,
                    children: [
                      HomeScreen(
                        active: _active,
                        nextKind: _nextKind,
                        actions: _actions,
                        reflections: _reflections,
                        defaultSnooze: _defaultSnooze,
                        onStart: _startSession,
                        onFinish: _finishFromApp,
                        onExtend: _extendActive,
                      ),
                      HistoryScreen(records: _records),
                      SettingsScreen(
                        actions: _actions,
                        reflections: _reflections,
                        defaultSnooze: _defaultSnooze,
                        onSaveNames: _saveNames,
                        onDefaultSnoozeChanged: _setDefaultSnooze,
                      ),
                    ],
                  ),
                ),
                bottomNavigationBar: NavigationBar(
                  selectedIndex: _tab,
                  onDestinationSelected: (value) => setState(() => _tab = value),
                  destinations: const [
                    NavigationDestination(
                      icon: Icon(Icons.timer_outlined),
                      selectedIcon: Icon(Icons.timer),
                      label: 'الآن',
                    ),
                    NavigationDestination(
                      icon: Icon(Icons.history),
                      label: 'السجل',
                    ),
                    NavigationDestination(
                      icon: Icon(Icons.settings_outlined),
                      selectedIcon: Icon(Icons.settings),
                      label: 'الإعدادات',
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({
    super.key,
    required this.active,
    required this.nextKind,
    required this.actions,
    required this.reflections,
    required this.defaultSnooze,
    required this.onStart,
    required this.onFinish,
    required this.onExtend,
  });

  final ActiveSession? active;
  final SessionKind? nextKind;
  final List<String> actions;
  final List<String> reflections;
  final int defaultSnooze;
  final Future<bool> Function({
    required SessionKind kind,
    required String name,
    required int minutes,
    required int snoozeMinutes,
  }) onStart;
  final Future<void> Function() onFinish;
  final Future<void> Function(int minutes) onExtend;

  @override
  Widget build(BuildContext context) {
    if (active != null) {
      return ActiveTimerView(
        session: active!,
        onFinish: onFinish,
        onExtend: onExtend,
      );
    }
    return StartSessionView(
      nextKind: nextKind,
      actions: actions,
      reflections: reflections,
      defaultSnooze: defaultSnooze,
      onStart: onStart,
    );
  }
}

class StartSessionView extends StatefulWidget {
  const StartSessionView({
    super.key,
    required this.nextKind,
    required this.actions,
    required this.reflections,
    required this.defaultSnooze,
    required this.onStart,
  });

  final SessionKind? nextKind;
  final List<String> actions;
  final List<String> reflections;
  final int defaultSnooze;
  final Future<bool> Function({
    required SessionKind kind,
    required String name,
    required int minutes,
    required int snoozeMinutes,
  }) onStart;

  @override
  State<StartSessionView> createState() => _StartSessionViewState();
}

class _StartSessionViewState extends State<StartSessionView> {
  late SessionKind _kind;
  String? _name;
  int _minutes = 15;
  late int _snooze;
  bool _starting = false;

  List<String> get _names =>
      _kind == SessionKind.action ? widget.actions : widget.reflections;

  @override
  void initState() {
    super.initState();
    _kind = widget.nextKind ?? SessionKind.reflection;
    _snooze = widget.defaultSnooze;
    _syncName();
    if (_kind == SessionKind.reflection) _minutes = 5;
  }

  @override
  void didUpdateWidget(covariant StartSessionView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.nextKind != widget.nextKind && widget.nextKind != null) {
      _kind = widget.nextKind!;
      _minutes = _kind == SessionKind.reflection ? 5 : 15;
      _syncName();
    }
  }

  void _syncName() {
    final values = _names;
    _name = values.isEmpty ? null : values.first;
  }

  Future<void> _customMinutes() async {
    final value = await _numberDialog(context, 'مدة التايمر بالدقائق', _minutes);
    if (value != null && mounted) setState(() => _minutes = value);
  }

  Future<void> _customSnooze() async {
    final value = await _numberDialog(context, 'مدة الغفوة بالدقائق', _snooze);
    if (value != null && mounted) setState(() => _snooze = value);
  }

  @override
  Widget build(BuildContext context) {
    final expected = widget.nextKind;
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 32),
      children: [
        const Text(
          'فعل ← جلسة ← فعل',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 6),
        Text(
          expected == null
              ? 'ابدأ بما تحتاجه الآن.'
              : expected == SessionKind.action
                  ? 'انتهت الجلسة. الخطوة التالية المقترحة: فعل.'
                  : 'انتهى الفعل. الخطوة التالية المقترحة: جلسة وعي.',
          style: Theme.of(context).textTheme.bodyLarge,
        ),
        const SizedBox(height: 22),
        SegmentedButton<SessionKind>(
          segments: const [
            ButtonSegment(
              value: SessionKind.action,
              icon: Icon(Icons.bolt),
              label: Text('فعل'),
            ),
            ButtonSegment(
              value: SessionKind.reflection,
              icon: Icon(Icons.psychology_alt_outlined),
              label: Text('جلسة'),
            ),
          ],
          selected: {_kind},
          onSelectionChanged: (value) {
            setState(() {
              _kind = value.first;
              _minutes = _kind == SessionKind.action ? 15 : 5;
              _syncName();
            });
          },
        ),
        const SizedBox(height: 22),
        Text('ماذا ستفعل؟', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 10),
        if (_names.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('أضف أسماء من صفحة الإعدادات أولًا.'),
            ),
          )
        else
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _names
                .map(
                  (name) => ChoiceChip(
                    label: Text(name),
                    selected: _name == name,
                    onSelected: (_) => setState(() => _name = name),
                  ),
                )
                .toList(),
          ),
        const SizedBox(height: 24),
        Text('المدة', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final value in [1, 3, 5, 10, 15, 20, 30, 45, 60])
              ChoiceChip(
                label: Text('$value د'),
                selected: _minutes == value,
                onSelected: (_) => setState(() => _minutes = value),
              ),
            ActionChip(
              avatar: const Icon(Icons.edit, size: 18),
              label: const Text('مدة أخرى'),
              onPressed: _customMinutes,
            ),
          ],
        ),
        const SizedBox(height: 24),
        Text('الغفوة بعد الرنين', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final value in [1, 2, 3, 5, 10, 15])
              ChoiceChip(
                label: Text('$value د'),
                selected: _snooze == value,
                onSelected: (_) => setState(() => _snooze = value),
              ),
            ActionChip(
              avatar: const Icon(Icons.edit, size: 18),
              label: const Text('مخصصة'),
              onPressed: _customSnooze,
            ),
          ],
        ),
        const SizedBox(height: 28),
        FilledButton.icon(
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(58),
            textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          ),
          onPressed: _starting || _name == null
              ? null
              : () async {
                  setState(() => _starting = true);
                  final ok = await widget.onStart(
                    kind: _kind,
                    name: _name!,
                    minutes: _minutes,
                    snoozeMinutes: _snooze,
                  );
                  if (!mounted) return;
                  setState(() => _starting = false);
                  if (!ok) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'تعذر ضبط المنبه. فعّل صلاحية المنبه الدقيق من الإعدادات.',
                        ),
                      ),
                    );
                  }
                },
          icon: _starting
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.play_arrow),
          label: Text(_kind == SessionKind.action ? 'ابدأ الفعل' : 'ابدأ الجلسة'),
        ),
      ],
    );
  }
}

class ActiveTimerView extends StatefulWidget {
  const ActiveTimerView({
    super.key,
    required this.session,
    required this.onFinish,
    required this.onExtend,
  });

  final ActiveSession session;
  final Future<void> Function() onFinish;
  final Future<void> Function(int minutes) onExtend;

  @override
  State<ActiveTimerView> createState() => _ActiveTimerViewState();
}

class _ActiveTimerViewState extends State<ActiveTimerView> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final difference = widget.session.plannedEndMillis - now;
    final overdue = difference < 0;
    final seconds = (difference.abs() / 1000).floor();
    final durationText = _clock(seconds);
    final progress = ((now - widget.session.startedAtMillis) /
            (widget.session.plannedMinutes * 60 * 1000))
        .clamp(0.0, 1.0)
        .toDouble();

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 28, 20, 32),
      children: [
        Row(
          children: [
            Icon(
              widget.session.kind == SessionKind.action
                  ? Icons.bolt
                  : Icons.psychology_alt_outlined,
              size: 34,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                widget.session.name,
                style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          widget.session.kind == SessionKind.action
              ? 'أنت الآن في فعل. بعده تأتي جلسة وعي.'
              : 'أنت الآن في جلسة. بعدها اختر الفعل التالي.',
        ),
        const SizedBox(height: 42),
        Center(
          child: Text(
            overdue ? '+$durationText' : durationText,
            textDirection: TextDirection.ltr,
            style: TextStyle(
              fontSize: 64,
              fontWeight: FontWeight.w800,
              color: overdue ? Theme.of(context).colorScheme.error : null,
            ),
          ),
        ),
        Center(
          child: Text(overdue ? 'وقت إضافي بعد انتهاء التايمر' : 'متبقي'),
        ),
        const SizedBox(height: 24),
        LinearProgressIndicator(value: progress, minHeight: 10),
        const SizedBox(height: 12),
        Text(
          'المخطط: ${widget.session.plannedMinutes} دقيقة • الغفوة: ${widget.session.snoozeMinutes} دقيقة',
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 30),
        if (!overdue) ...[
          const Text('تمديد قبل انتهاء الوقت', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: OutlinedButton(onPressed: () => widget.onExtend(1), child: const Text('+1 دقيقة'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton(onPressed: () => widget.onExtend(5), child: const Text('+5 دقائق'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton(onPressed: () => widget.onExtend(10), child: const Text('+10 دقائق'))),
            ],
          ),
          const SizedBox(height: 18),
        ],
        FilledButton.icon(
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
          onPressed: () async {
            final confirm = await showDialog<bool>(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text('إنهاء المرحلة؟'),
                content: Text(
                  widget.session.kind == SessionKind.action
                      ? 'سيتم تسجيل الفعل، ثم سيقترح التطبيق جلسة وعي.'
                      : 'سيتم تسجيل الجلسة، ثم سيقترح التطبيق الفعل التالي.',
                ),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('رجوع')),
                  FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('انتهيت')),
                ],
              ),
            );
            if (confirm == true) await widget.onFinish();
          },
          icon: const Icon(Icons.check_circle_outline),
          label: const Text('انتهيت الآن'),
        ),
        const SizedBox(height: 12),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'عند رنين المنبه: زر رفع الصوت = غفوة مؤقتة. زر «انتهيت» في شاشة المنبه = إنهاء المرحلة وفتح التطبيق.',
            ),
          ),
        ),
      ],
    );
  }
}

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key, required this.records});

  final List<SessionRecord> records;

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final todayRecords = records.where((record) {
      final d = DateTime.fromMillisecondsSinceEpoch(record.startedAtMillis);
      return d.year == today.year && d.month == today.month && d.day == today.day;
    }).toList();
    final actionSeconds = todayRecords
        .where((e) => e.kind == SessionKind.action)
        .fold<int>(0, (sum, e) => sum + e.actualSeconds);
    final reflectionSeconds = todayRecords
        .where((e) => e.kind == SessionKind.reflection)
        .fold<int>(0, (sum, e) => sum + e.actualSeconds);
    final snoozes = todayRecords.fold<int>(0, (sum, e) => sum + e.snoozeCount);
    final overrun = todayRecords.fold<int>(0, (sum, e) => sum + e.overrunSeconds);

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 22, 18, 32),
      children: [
        const Text('سجل اليوم', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _StatCard(label: 'الأفعال', value: _humanDuration(actionSeconds)),
            _StatCard(label: 'الجلسات', value: _humanDuration(reflectionSeconds)),
            _StatCard(label: 'الغفوات', value: '$snoozes'),
            _StatCard(label: 'التجاوز', value: _humanDuration(overrun)),
          ],
        ),
        const SizedBox(height: 24),
        if (todayRecords.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Text('لا توجد جلسات مسجلة اليوم بعد.'),
            ),
          )
        else
          for (final record in todayRecords) _RecordCard(record: record),
        if (records.length > todayRecords.length) ...[
          const SizedBox(height: 24),
          const Text('السجل السابق', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          for (final record in records.where((e) => !todayRecords.contains(e)).take(30))
            _RecordCard(record: record),
        ],
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => SizedBox(
        width: 155,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 6),
                Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              ],
            ),
          ),
        ),
      );
}

class _RecordCard extends StatelessWidget {
  const _RecordCard({required this.record});
  final SessionRecord record;

  @override
  Widget build(BuildContext context) {
    final start = DateTime.fromMillisecondsSinceEpoch(record.startedAtMillis);
    final end = DateTime.fromMillisecondsSinceEpoch(record.endedAtMillis);
    final time = '${intl.DateFormat('HH:mm').format(start)} – ${intl.DateFormat('HH:mm').format(end)}';
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          child: Icon(record.kind == SessionKind.action ? Icons.bolt : Icons.psychology_alt_outlined),
        ),
        title: Text(record.name, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(
          '$time\nفعلي ${_humanDuration(record.actualSeconds)} • مخطط ${record.plannedMinutes} د • غفوات ${record.snoozeCount}'
          '${record.overrunSeconds > 0 ? ' • +${_humanDuration(record.overrunSeconds)}' : ''}',
        ),
        isThreeLine: true,
      ),
    );
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({
    super.key,
    required this.actions,
    required this.reflections,
    required this.defaultSnooze,
    required this.onSaveNames,
    required this.onDefaultSnoozeChanged,
  });

  final List<String> actions;
  final List<String> reflections;
  final int defaultSnooze;
  final Future<void> Function(SessionKind kind, List<String> names) onSaveNames;
  final Future<void> Function(int value) onDefaultSnoozeChanged;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  Map<String, dynamic> _permissions = const {};

  @override
  void initState() {
    super.initState();
    _refreshPermissions();
  }

  Future<void> _refreshPermissions() async {
    try {
      final value = await NativeAlarm.permissionStatus();
      if (mounted) setState(() => _permissions = value);
    } catch (_) {}
  }

  Future<void> _addName(SessionKind kind) async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(kind == SessionKind.action ? 'إضافة فعل' : 'إضافة جلسة'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'الاسم'),
          onSubmitted: (v) => Navigator.pop(context, v.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('إضافة')),
        ],
      ),
    );
    if (value == null || value.isEmpty) return;
    final source = kind == SessionKind.action ? widget.actions : widget.reflections;
    if (source.contains(value)) return;
    await widget.onSaveNames(kind, [...source, value]);
  }

  Future<void> _removeName(SessionKind kind, String value) async {
    final source = kind == SessionKind.action ? widget.actions : widget.reflections;
    await widget.onSaveNames(kind, source.where((e) => e != value).toList());
  }

  Widget _permissionTile({
    required String title,
    required bool granted,
    required String subtitle,
    required VoidCallback onPressed,
  }) => Card(
        child: ListTile(
          leading: Icon(granted ? Icons.check_circle : Icons.warning_amber_rounded),
          title: Text(title),
          subtitle: Text(subtitle),
          trailing: granted ? const Text('مفعلة') : TextButton(onPressed: onPressed, child: const Text('تفعيل')),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final notifications = _permissions['notifications'] == true;
    final exact = _permissions['exactAlarm'] == true;
    final fullScreen = _permissions['fullScreen'] == true;
    return RefreshIndicator(
      onRefresh: _refreshPermissions,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 22, 18, 32),
        children: [
          const Text('الإعدادات', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          const Text('صلاحيات المنبه', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          _permissionTile(
            title: 'الإشعارات',
            granted: notifications,
            subtitle: 'مطلوبة لإظهار منبه Android والإشعار الأمامي.',
            onPressed: () async {
              await NativeAlarm.requestNotificationPermission();
              await Future<void>.delayed(const Duration(milliseconds: 500));
              await _refreshPermissions();
            },
          ),
          _permissionTile(
            title: 'المنبه الدقيق',
            granted: exact,
            subtitle: 'مهم لكي يرن في الوقت المحدد حتى مع خمول الهاتف.',
            onPressed: () async {
              await NativeAlarm.openExactAlarmSettings();
            },
          ),
          _permissionTile(
            title: 'ملء الشاشة',
            granted: fullScreen,
            subtitle: 'يساعد شاشة المنبه على الظهور فوق شاشة القفل.',
            onPressed: () async {
              await NativeAlarm.openFullScreenSettings();
            },
          ),
          TextButton.icon(onPressed: _refreshPermissions, icon: const Icon(Icons.refresh), label: const Text('تحديث حالة الصلاحيات')),
          const Divider(height: 34),
          const Text('الغفوة الافتراضية', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              for (final value in [1, 2, 3, 5, 10, 15])
                ChoiceChip(
                  label: Text('$value د'),
                  selected: widget.defaultSnooze == value,
                  onSelected: (_) => widget.onDefaultSnoozeChanged(value),
                ),
            ],
          ),
          const Divider(height: 34),
          _NameManager(
            title: 'الأفعال',
            values: widget.actions,
            onAdd: () => _addName(SessionKind.action),
            onRemove: (value) => _removeName(SessionKind.action, value),
          ),
          const SizedBox(height: 20),
          _NameManager(
            title: 'الجلسات',
            values: widget.reflections,
            onAdd: () => _addName(SessionKind.reflection),
            onRemove: (value) => _removeName(SessionKind.reflection, value),
          ),
          const Divider(height: 34),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'مهم: Android هو الذي يحدد مسار الصوت عند توصيل Earbuds. التطبيق يستخدم مسار ALARM الحقيقي، لكنه لا يجبر كل الأجهزة على تشغيل الصوت من السماعة الخارجية إذا كان النظام يوجه صوت المنبه لسماعة أخرى.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _NameManager extends StatelessWidget {
  const _NameManager({
    required this.title,
    required this.values,
    required this.onAdd,
    required this.onRemove,
  });

  final String title;
  final List<String> values;
  final VoidCallback onAdd;
  final void Function(String value) onRemove;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700))),
              IconButton(onPressed: onAdd, icon: const Icon(Icons.add_circle_outline), tooltip: 'إضافة'),
            ],
          ),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: values
                .map(
                  (value) => InputChip(
                    label: Text(value),
                    onDeleted: () => onRemove(value),
                  ),
                )
                .toList(),
          ),
        ],
      );
}

Future<int?> _numberDialog(BuildContext context, String title, int initial) async {
  final controller = TextEditingController(text: '$initial');
  return showDialog<int>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        autofocus: true,
        decoration: const InputDecoration(suffixText: 'دقيقة'),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(
          onPressed: () {
            final value = int.tryParse(controller.text.trim());
            Navigator.pop(context, value != null && value > 0 && value <= 1440 ? value : null);
          },
          child: const Text('حفظ'),
        ),
      ],
    ),
  );
}

String _clock(int seconds) {
  final h = seconds ~/ 3600;
  final m = (seconds % 3600) ~/ 60;
  final s = seconds % 60;
  if (h > 0) {
    return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }
  return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
}

String _humanDuration(int seconds) {
  if (seconds < 60) return '$seconds ث';
  final minutes = seconds ~/ 60;
  if (minutes < 60) return '$minutes د';
  final hours = minutes ~/ 60;
  final rest = minutes % 60;
  return rest == 0 ? '$hours س' : '$hours س $rest د';
}
