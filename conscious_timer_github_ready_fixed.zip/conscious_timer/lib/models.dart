import 'dart:convert';

enum SessionKind { action, reflection }

extension SessionKindX on SessionKind {
  String get key => this == SessionKind.action ? 'action' : 'reflection';
  String get arabic => this == SessionKind.action ? 'فعل' : 'جلسة';

  static SessionKind fromKey(String value) =>
      value == 'reflection' ? SessionKind.reflection : SessionKind.action;
}

class ActiveSession {
  const ActiveSession({
    required this.id,
    required this.kind,
    required this.name,
    required this.plannedMinutes,
    required this.snoozeMinutes,
    required this.startedAtMillis,
  });

  final String id;
  final SessionKind kind;
  final String name;
  final int plannedMinutes;
  final int snoozeMinutes;
  final int startedAtMillis;

  int get plannedEndMillis =>
      startedAtMillis + Duration(minutes: plannedMinutes).inMilliseconds;

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind.key,
        'name': name,
        'plannedMinutes': plannedMinutes,
        'snoozeMinutes': snoozeMinutes,
        'startedAtMillis': startedAtMillis,
      };

  factory ActiveSession.fromJson(Map<String, dynamic> json) => ActiveSession(
        id: json['id'] as String,
        kind: SessionKindX.fromKey(json['kind'] as String),
        name: json['name'] as String,
        plannedMinutes: (json['plannedMinutes'] as num).toInt(),
        snoozeMinutes: (json['snoozeMinutes'] as num).toInt(),
        startedAtMillis: (json['startedAtMillis'] as num).toInt(),
      );
}

class SessionRecord {
  const SessionRecord({
    required this.id,
    required this.kind,
    required this.name,
    required this.plannedMinutes,
    required this.snoozeMinutes,
    required this.startedAtMillis,
    required this.endedAtMillis,
    required this.snoozeCount,
  });

  final String id;
  final SessionKind kind;
  final String name;
  final int plannedMinutes;
  final int snoozeMinutes;
  final int startedAtMillis;
  final int endedAtMillis;
  final int snoozeCount;

  int get actualSeconds =>
      ((endedAtMillis - startedAtMillis) / 1000).round().clamp(0, 1 << 31).toInt();
  int get plannedSeconds => plannedMinutes * 60;
  int get overrunSeconds => (actualSeconds - plannedSeconds).clamp(0, 1 << 31).toInt();

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind.key,
        'name': name,
        'plannedMinutes': plannedMinutes,
        'snoozeMinutes': snoozeMinutes,
        'startedAtMillis': startedAtMillis,
        'endedAtMillis': endedAtMillis,
        'snoozeCount': snoozeCount,
      };

  factory SessionRecord.fromJson(Map<String, dynamic> json) => SessionRecord(
        id: json['id'] as String,
        kind: SessionKindX.fromKey(json['kind'] as String),
        name: json['name'] as String,
        plannedMinutes: (json['plannedMinutes'] as num).toInt(),
        snoozeMinutes: (json['snoozeMinutes'] as num).toInt(),
        startedAtMillis: (json['startedAtMillis'] as num).toInt(),
        endedAtMillis: (json['endedAtMillis'] as num).toInt(),
        snoozeCount: (json['snoozeCount'] as num).toInt(),
      );
}

String encodeRecords(List<SessionRecord> records) =>
    jsonEncode(records.map((e) => e.toJson()).toList());

List<SessionRecord> decodeRecords(String? raw) {
  if (raw == null || raw.isEmpty) return <SessionRecord>[];
  final decoded = jsonDecode(raw) as List<dynamic>;
  return decoded
      .map((e) => SessionRecord.fromJson(e as Map<String, dynamic>))
      .toList();
}
