import 'package:flutter/services.dart';

class NativeAlarm {
  NativeAlarm._();

  static const MethodChannel _channel = MethodChannel('conscious_timer/alarm');

  static Future<Map<String, dynamic>> permissionStatus() async {
    final value = await _channel.invokeMapMethod<String, dynamic>('permissionStatus');
    return Map<String, dynamic>.from(value ?? const {});
  }

  static Future<void> requestNotificationPermission() =>
      _channel.invokeMethod<void>('requestNotificationPermission');

  static Future<void> openExactAlarmSettings() =>
      _channel.invokeMethod<void>('openExactAlarmSettings');

  static Future<void> openFullScreenSettings() =>
      _channel.invokeMethod<void>('openFullScreenSettings');

  static Future<bool> schedule({
    required int triggerAtMillis,
    required String sessionId,
    required String title,
    required String body,
    required int snoozeMinutes,
  }) async {
    final result = await _channel.invokeMethod<bool>('schedule', {
      'triggerAtMillis': triggerAtMillis,
      'sessionId': sessionId,
      'title': title,
      'body': body,
      'snoozeMinutes': snoozeMinutes,
    });
    return result ?? false;
  }

  static Future<void> cancel() => _channel.invokeMethod<void>('cancel');

  static Future<int> getSnoozeCount() async =>
      await _channel.invokeMethod<int>('getSnoozeCount') ?? 0;

  static Future<Map<String, dynamic>?> consumePendingAction() async {
    final value = await _channel.invokeMapMethod<String, dynamic>('consumePendingAction');
    if (value == null || value.isEmpty) return null;
    return Map<String, dynamic>.from(value);
  }
}
