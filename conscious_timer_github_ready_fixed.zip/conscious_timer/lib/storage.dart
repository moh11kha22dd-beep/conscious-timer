import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class AppStorage {
  static const _activeKey = 'active_session_v1';
  static const _recordsKey = 'session_records_v1';
  static const _actionsKey = 'action_names_v1';
  static const _reflectionsKey = 'reflection_names_v1';
  static const _nextKindKey = 'next_kind_v1';
  static const _defaultSnoozeKey = 'default_snooze_v1';

  static const defaultActions = <String>[
    'مذاكرة',
    'ألماني',
    'قراءة',
    'كورس ICU',
    'شغل',
    'تدريب مستشفى',
    'قرآن',
  ];

  static const defaultReflections = <String>[
    'تفكير',
    'محاسبة',
    'تدبر',
    'وعي',
    'تخطيط',
  ];

  Future<SharedPreferences> get _prefs => SharedPreferences.getInstance();

  Future<ActiveSession?> loadActive() async {
    final raw = (await _prefs).getString(_activeKey);
    if (raw == null || raw.isEmpty) return null;
    try {
      return ActiveSession.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<void> saveActive(ActiveSession? session) async {
    final prefs = await _prefs;
    if (session == null) {
      await prefs.remove(_activeKey);
    } else {
      await prefs.setString(_activeKey, jsonEncode(session.toJson()));
    }
  }

  Future<List<SessionRecord>> loadRecords() async =>
      decodeRecords((await _prefs).getString(_recordsKey));

  Future<void> saveRecords(List<SessionRecord> records) async =>
      (await _prefs).setString(_recordsKey, encodeRecords(records));

  Future<List<String>> loadActions() async =>
      (await _prefs).getStringList(_actionsKey) ?? [...defaultActions];

  Future<List<String>> loadReflections() async =>
      (await _prefs).getStringList(_reflectionsKey) ?? [...defaultReflections];

  Future<void> saveActions(List<String> values) async =>
      (await _prefs).setStringList(_actionsKey, values);

  Future<void> saveReflections(List<String> values) async =>
      (await _prefs).setStringList(_reflectionsKey, values);

  Future<SessionKind?> loadNextKind() async {
    final value = (await _prefs).getString(_nextKindKey);
    return value == null ? null : SessionKindX.fromKey(value);
  }

  Future<void> saveNextKind(SessionKind? value) async {
    final prefs = await _prefs;
    if (value == null) {
      await prefs.remove(_nextKindKey);
    } else {
      await prefs.setString(_nextKindKey, value.key);
    }
  }

  Future<int> loadDefaultSnooze() async =>
      (await _prefs).getInt(_defaultSnoozeKey) ?? 5;

  Future<void> saveDefaultSnooze(int minutes) async =>
      (await _prefs).setInt(_defaultSnoozeKey, minutes);
}
