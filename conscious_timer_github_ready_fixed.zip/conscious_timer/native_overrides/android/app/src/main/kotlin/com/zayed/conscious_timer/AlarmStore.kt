package com.zayed.conscious_timer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object AlarmStore {
    private const val PREFS = "conscious_timer_native_alarm"
    private const val REQUEST_CODE = 41001

    private const val K_SESSION = "session_id"
    private const val K_TRIGGER = "trigger_at"
    private const val K_TITLE = "title"
    private const val K_BODY = "body"
    private const val K_SNOOZE_MIN = "snooze_minutes"
    private const val K_SNOOZE_COUNT = "snooze_count"

    private const val K_PENDING_ACTION = "pending_action"
    private const val K_PENDING_SESSION = "pending_session"
    private const val K_PENDING_FINISHED = "pending_finished"
    private const val K_PENDING_SNOOZES = "pending_snoozes"

    data class AlarmData(
        val sessionId: String,
        val triggerAtMillis: Long,
        val title: String,
        val body: String,
        val snoozeMinutes: Int,
        val snoozeCount: Int,
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun canScheduleExact(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return manager.canScheduleExactAlarms()
    }

    fun schedule(
        context: Context,
        triggerAtMillis: Long,
        sessionId: String,
        title: String,
        body: String,
        snoozeMinutes: Int,
    ): Boolean {
        return scheduleInternal(
            context = context,
            triggerAtMillis = triggerAtMillis,
            sessionId = sessionId,
            title = title,
            body = body,
            snoozeMinutes = snoozeMinutes,
            snoozeCount = 0,
        )
    }

    private fun scheduleInternal(
        context: Context,
        triggerAtMillis: Long,
        sessionId: String,
        title: String,
        body: String,
        snoozeMinutes: Int,
        snoozeCount: Int,
    ): Boolean {
        if (!canScheduleExact(context)) return false
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = alarmPendingIntent(context)
        return try {
            manager.cancel(pendingIntent)
            manager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                pendingIntent,
            )
            prefs(context).edit()
                .putString(K_SESSION, sessionId)
                .putLong(K_TRIGGER, triggerAtMillis)
                .putString(K_TITLE, title)
                .putString(K_BODY, body)
                .putInt(K_SNOOZE_MIN, snoozeMinutes.coerceAtLeast(1))
                .putInt(K_SNOOZE_COUNT, snoozeCount.coerceAtLeast(0))
                .apply()
            true
        } catch (_: SecurityException) {
            false
        }
    }

    fun load(context: Context): AlarmData? {
        val p = prefs(context)
        val session = p.getString(K_SESSION, null) ?: return null
        return AlarmData(
            sessionId = session,
            triggerAtMillis = p.getLong(K_TRIGGER, 0L),
            title = p.getString(K_TITLE, "انتهى الوقت") ?: "انتهى الوقت",
            body = p.getString(K_BODY, "افتح التطبيق للمتابعة") ?: "افتح التطبيق للمتابعة",
            snoozeMinutes = p.getInt(K_SNOOZE_MIN, 5).coerceAtLeast(1),
            snoozeCount = p.getInt(K_SNOOZE_COUNT, 0).coerceAtLeast(0),
        )
    }

    fun snooze(context: Context): Boolean {
        val data = load(context) ?: return false
        val nextCount = data.snoozeCount + 1
        val nextAt = System.currentTimeMillis() + data.snoozeMinutes * 60_000L
        return scheduleInternal(
            context = context,
            triggerAtMillis = nextAt,
            sessionId = data.sessionId,
            title = data.title,
            body = data.body,
            snoozeMinutes = data.snoozeMinutes,
            snoozeCount = nextCount,
        )
    }

    fun finish(context: Context) {
        val data = load(context) ?: return
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        manager.cancel(alarmPendingIntent(context))
        prefs(context).edit()
            .remove(K_SESSION)
            .remove(K_TRIGGER)
            .remove(K_TITLE)
            .remove(K_BODY)
            .remove(K_SNOOZE_MIN)
            .remove(K_SNOOZE_COUNT)
            .putString(K_PENDING_ACTION, "finish")
            .putString(K_PENDING_SESSION, data.sessionId)
            .putLong(K_PENDING_FINISHED, System.currentTimeMillis())
            .putInt(K_PENDING_SNOOZES, data.snoozeCount)
            .apply()
    }

    fun cancel(context: Context) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        manager.cancel(alarmPendingIntent(context))
        prefs(context).edit()
            .remove(K_SESSION)
            .remove(K_TRIGGER)
            .remove(K_TITLE)
            .remove(K_BODY)
            .remove(K_SNOOZE_MIN)
            .remove(K_SNOOZE_COUNT)
            .apply()
        context.stopService(Intent(context, AlarmService::class.java))
    }

    fun getSnoozeCount(context: Context): Int =
        prefs(context).getInt(K_SNOOZE_COUNT, 0).coerceAtLeast(0)

    fun consumePendingAction(context: Context): Map<String, Any>? {
        val p = prefs(context)
        val action = p.getString(K_PENDING_ACTION, null) ?: return null
        val result = mapOf<String, Any>(
            "action" to action,
            "sessionId" to (p.getString(K_PENDING_SESSION, "") ?: ""),
            "finishedAtMillis" to p.getLong(K_PENDING_FINISHED, System.currentTimeMillis()),
            "snoozeCount" to p.getInt(K_PENDING_SNOOZES, 0),
        )
        p.edit()
            .remove(K_PENDING_ACTION)
            .remove(K_PENDING_SESSION)
            .remove(K_PENDING_FINISHED)
            .remove(K_PENDING_SNOOZES)
            .apply()
        return result
    }

    fun restoreAfterBoot(context: Context) {
        val data = load(context) ?: return
        val nextAt = if (data.triggerAtMillis > System.currentTimeMillis()) {
            data.triggerAtMillis
        } else {
            System.currentTimeMillis() + 5_000L
        }
        scheduleInternal(
            context = context,
            triggerAtMillis = nextAt,
            sessionId = data.sessionId,
            title = data.title,
            body = data.body,
            snoozeMinutes = data.snoozeMinutes,
            snoozeCount = data.snoozeCount,
        )
    }

    private fun alarmPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.zayed.conscious_timer.ALARM"
        }
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}
