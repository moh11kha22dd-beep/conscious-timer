package com.zayed.conscious_timer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            ACTION_SNOOZE -> {
                AlarmStore.snooze(context)
                context.stopService(Intent(context, AlarmService::class.java))
            }
            ACTION_FINISH -> {
                AlarmStore.finish(context)
                context.stopService(Intent(context, AlarmService::class.java))
                val openApp = Intent(context, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                context.startActivity(openApp)
            }
        }
    }

    companion object {
        const val ACTION_SNOOZE = "com.zayed.conscious_timer.SNOOZE"
        const val ACTION_FINISH = "com.zayed.conscious_timer.FINISH"
    }
}
