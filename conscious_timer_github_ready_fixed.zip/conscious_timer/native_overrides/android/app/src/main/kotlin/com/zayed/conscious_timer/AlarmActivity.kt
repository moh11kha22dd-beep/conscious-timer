package com.zayed.conscious_timer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView

class AlarmActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        render()
    }

    private fun render() {
        val data = AlarmStore.load(this)
        if (data == null) {
            finish()
            return
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(48), dp(24), dp(28))
            setBackgroundColor(Color.rgb(248, 248, 244))
        }

        root.addView(TextView(this).apply {
            text = "انتهى الوقت"
            textSize = 20f
            gravity = Gravity.CENTER
        }, matchWrap())

        root.addView(TextView(this).apply {
            text = data.title
            textSize = 32f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(25, 25, 25))
            setPadding(0, dp(18), 0, dp(12))
        }, matchWrap())

        root.addView(TextView(this).apply {
            text = data.body
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(12))
        }, matchWrap())

        root.addView(TextView(this).apply {
            text = "الغفوات حتى الآن: ${data.snoozeCount}"
            textSize = 16f
            gravity = Gravity.CENTER
        }, matchWrap())

        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))

        root.addView(Button(this).apply {
            text = "غفوة ${data.snoozeMinutes} دقائق"
            textSize = 20f
            setOnClickListener { snooze() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)).apply {
            bottomMargin = dp(12)
        })

        root.addView(Button(this).apply {
            text = "✓ انتهيت"
            textSize = 20f
            setOnClickListener { finishSession() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)))

        root.addView(TextView(this).apply {
            text = "يمكنك الضغط على زر رفع الصوت للغفوة مباشرة"
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        }, matchWrap())

        setContentView(root)
    }

    private fun snooze() {
        AlarmStore.snooze(this)
        stopService(Intent(this, AlarmService::class.java))
        finishAndRemoveTask()
    }

    private fun finishSession() {
        AlarmStore.finish(this)
        stopService(Intent(this, AlarmService::class.java))
        val openApp = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(openApp)
        finishAndRemoveTask()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            snooze()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Back is intentionally disabled while the alarm is active")
    override fun onBackPressed() {
        // The alarm must be explicitly snoozed or finished.
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
    )
}
