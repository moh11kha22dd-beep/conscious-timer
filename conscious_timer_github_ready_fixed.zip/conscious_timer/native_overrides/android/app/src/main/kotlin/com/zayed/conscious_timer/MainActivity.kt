package com.zayed.conscious_timer

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "conscious_timer/alarm"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            channelName,
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "permissionStatus" -> result.success(permissionStatus())
                "requestNotificationPermission" -> {
                    requestNotificationPermission()
                    result.success(null)
                }
                "openExactAlarmSettings" -> {
                    openExactAlarmSettings()
                    result.success(null)
                }
                "openFullScreenSettings" -> {
                    openFullScreenSettings()
                    result.success(null)
                }
                "schedule" -> {
                    val triggerAt = call.argument<Number>("triggerAtMillis")?.toLong()
                    val sessionId = call.argument<String>("sessionId")
                    val title = call.argument<String>("title")
                    val body = call.argument<String>("body")
                    val snooze = call.argument<Number>("snoozeMinutes")?.toInt()
                    if (triggerAt == null || sessionId == null || title == null || body == null || snooze == null) {
                        result.error("bad_args", "Missing alarm arguments", null)
                    } else {
                        result.success(
                            AlarmStore.schedule(
                                context = this,
                                triggerAtMillis = triggerAt,
                                sessionId = sessionId,
                                title = title,
                                body = body,
                                snoozeMinutes = snooze,
                            ),
                        )
                    }
                }
                "cancel" -> {
                    AlarmStore.cancel(this)
                    result.success(null)
                }
                "getSnoozeCount" -> result.success(AlarmStore.getSnoozeCount(this))
                "consumePendingAction" -> result.success(AlarmStore.consumePendingAction(this))
                else -> result.notImplemented()
            }
        }
    }

    private fun permissionStatus(): Map<String, Boolean> {
        val notifications = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exactAlarm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val fullScreen = if (Build.VERSION.SDK_INT >= 34) {
            notificationManager.canUseFullScreenIntent()
        } else {
            true
        }

        return mapOf(
            "notifications" to notifications,
            "exactAlarm" to exactAlarm,
            "fullScreen" to fullScreen,
        )
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001)
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(
                Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                Uri.parse("package:$packageName"),
            )
            startActivity(intent)
        }
    }

    private fun openFullScreenSettings() {
        if (Build.VERSION.SDK_INT >= 34) {
            val intent = Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT").apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        }
    }
}
